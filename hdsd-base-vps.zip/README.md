# Hướng dẫn sử dụng Base – Công ty thiết kế VPS

Tài liệu hướng dẫn sử dụng **Base Account → Base Workforce → Base Project** cho Công ty thiết kế VPS, gói gọn trong một file HTML.

**Xem online:** https://hlananh14.github.io/hdsd-base-vps/

## Nội dung

| Phần | Dành cho | Nội dung |
|---|---|---|
| Lộ trình | Mọi người | 3 tầng Account → Workforce → Project, mỗi tầng trả lời câu hỏi gì, ai thiết lập |
| Cẩm nang thiết lập | PIC | Khái niệm, các bước, checklist, lỗi hay gặp khi dựng 3 tầng lần đầu |
| Vai trò | Mọi người | Chọn Người thiết lập / Người maintain / Người dùng cuối |
| Hướng dẫn | Mọi người | 34 thao tác, 168 bước có ảnh chụp, tự chạy và phóng to đúng chỗ cần bấm |
| Cẩm nang Project | PM, xưởng, BGĐ | 11 chủ đề quy ước riêng của VPS trên Base Project |

Tìm nhanh mọi thao tác bằng **Ctrl K** hoặc phím **/**.

## Cập nhật nội dung

1. Mở `index.html` bằng trình duyệt (Chrome, Edge…).
2. Bấm **✎ Chỉnh sửa** để sửa chữ, kéo số trên ảnh, bấm đúp vào ảnh để thay ảnh.
3. Bấm **Lưu file** để tải về bản đã sửa.
4. Đổi tên file tải về thành `index.html`, ghi đè vào repo rồi commit – trang online tự cập nhật sau 1–2 phút.

## Lưu ý

Ảnh chụp màn hình lấy từ môi trường demo Base, có tên và email nhân sự (dữ liệu demo @vpsdesign.test). Kiểm tra trước khi chia sẻ ra ngoài công ty.
